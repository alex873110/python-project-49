from brain_games.games.even_game import even_question
from brain_games.games.common_functions import question


def main():
    question(even_question)


if __name__ == '__main__':
    main()
