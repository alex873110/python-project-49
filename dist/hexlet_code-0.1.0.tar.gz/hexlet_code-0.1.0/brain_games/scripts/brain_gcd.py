from brain_games.games.gcd_game import bg_gcd
from brain_games.games.common_functions import question


def main():
    question(bg_gcd)


if __name__ == '__main__':
    main()
