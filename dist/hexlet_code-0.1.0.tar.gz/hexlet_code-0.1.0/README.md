### Hexlet tests and linter status:
[![Actions Status](https://github.com/alex873110/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/alex873110/python-project-49/actions)

# Code Climate Maintainability Badge link 
<a href="https://codeclimate.com/github/alex873110/python-project-49/maintainability"><img 
src="https://api.codeclimate.com/v1/badges/d933dc886756d0a1eb03/maintainability" /></a>
