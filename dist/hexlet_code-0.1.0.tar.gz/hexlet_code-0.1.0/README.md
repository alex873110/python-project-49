### Hexlet tests and linter status:
[![Actions Status](https://github.com/alex873110/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/alex873110/python-project-49/actions)

# Code Climate Maintainability Badge link 
<a href="https://codeclimate.com/github/alex873110/python-project-49/maintainability"><img 
src="https://api.codeclimate.com/v1/badges/d933dc886756d0a1eb03/maintainability" /></a>

# Link to asciinema video with brain-even game test 
https://asciinema.org/connect/2eaa6a65-5745-4524-9282-776349ae28da

# Link to asciinema video with brain-calc game test
https://asciinema.org/a/AMPisdRse5gNXlLl9vOKQKV0j

# Link to asciinema video with brain-gcd game test
https://asciinema.org/a/Jtb2vQReLdH6jtmeyu4i3RCl2

# Link to asciinema video with brain-progression game test
https://asciinema.org/a/N2qr42Wbwzdo8bEADIEIK6q1r
