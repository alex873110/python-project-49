from brain_games.games.common_functions import question
from brain_games.games.progression_game import bg_progression


def main():
    question(bg_progression)


if __name__ == '__main__':
    main()
