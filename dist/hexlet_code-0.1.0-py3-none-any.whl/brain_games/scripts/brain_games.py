#!/usr/bin/env python3
def welcome():
    print('Welcome to the Brain Games!')


def main():
    welcome()


if __name__ == '__main__':
    main()

