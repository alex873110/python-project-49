from brain_games.games.prime_game import bg_is_prime
from brain_games.games.common_functions import question


def main():
    question(bg_is_prime)


if __name__ == '__main__':
    main()
